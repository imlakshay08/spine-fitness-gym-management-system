

var $uploadCrop, rawImg;



function readFile(input) {

  if (input.files && input.files[0]) {

    var reader = new FileReader();

    reader.onload = function (e) {

      $('.upload-demo').addClass('ready');

      $('#cropImagePop').modal('show');

      rawImg = e.target.result;

    }

    reader.readAsDataURL(input.files[0]);

  } else {

    alert("Sorry - your browser doesn't support the FileReader API");

  }

}



$uploadCrop = $('#upload-demo').croppie({

  viewport: {

    width: 300,

    height: 300

  },

  enforceBoundary: false,

  enableExif: true

});



$('#cropImagePop').on('shown.bs.modal', function() {

  $uploadCrop.croppie('bind', {

    url: rawImg

  }).then(function() {

    console.log('jQuery bind complete');

  });

});



$('.item-img').on('change', function () {

  readFile(this);

});



$('#cropImageBtn').on('click', function () {

  $uploadCrop.croppie('result', {

    type: 'base64',

    format: 'png',

    size: {width: 300, height: 300}

  }).then(function (resp) {

    $('#item-img-output').attr('src', resp);

    $("#studentattach_file").val(resp);

    $('#cropImagePop').modal('hide');

    

  });

});





var $uploadCro, rawIm;



function readFile(input) {

  if (input.files && input.files[0]) {

    var reader = new FileReader();

    reader.onload = function (e) {

      $('.upload-demo').addClass('ready');

      $('#cropImagePop').modal('show');

      rawIm = e.target.result;

    }

    reader.readAsDataURL(input.files[0]);

  } else {

    alert("Sorry - your browser doesn't support the FileReader API");

  }

}



$uploadCro = $('#upload-demo').croppie({

  viewport: {

    width: 300,

    height: 300

  },

  enforceBoundary: false,

  enableExif: true

});



$('#cropImagePop').on('shown.bs.modal', function() {

  $uploadCro.croppie('bind', {

    url: rawIm

  }).then(function() {

    console.log('jQuery bind complete');

  });

});



$('.item-im').on('change', function () {

  readFile(this);

});



$('#cropImageBtn').on('click', function () {

  $uploadCro.croppie('result', {

    type: 'base64',

    format: 'png',

    size: {width: 300, height: 300}

  }).then(function (resp) {

    $('#item-img-outpu').attr('src', resp);

    $("#studentattach_fil").val(resp);

    $('#cropImagePop').modal('hide');

    

  });

});



function set_global_focus(id){

  $("#"+id).focus();

}



function process_save_student_details(){

  var usePath = $.trim($("#rootXPath").val());

  var formData = new FormData();

  var mid = $.trim($("#mid").val());

  var stdnt_reg_no = $.trim($("#stdnt_reg_no").val());

  var signature = $('#stdnt_signature').get(0).files[0];

  var stdnt_img = $('#stdnt_img').get(0).files[0];



  if( stdnt_reg_no === ''){

    showToast("error", "Registration number is required.");

    set_global_focus('stdnt_reg_no');

    return false;

  } 



  formData.append("identity", "STDNT");

  formData.append("mid", mid);

  formData.append("stdnt_reg_no", stdnt_reg_no);



  if (signature) formData.append("stdnt_signature", signature);

  if (stdnt_img) formData.append("stdnt_img", stdnt_img);



  $.ajax({

    url: usePath + "student_info/ajax_process",

    type: 'POST',

    data: formData,

    async: false,

    contentType: false,

    processData: false,

    success: function (resp) {

      if(resp.status){

        $("#mid").val(resp.profileid);

        $("#currcategoryimage").val(resp.profileimage);

        $("#cursignature").val(resp.signimages);

      } else {

        alert(resp.message);

      }

    },

    error: function () {

      showToast("error", "An error occurred while processing.");

    }

  });

}







function sendOTPEmail() {

  var usePath = $.trim($("#rootXPath").val());
  var regNo = $.trim($("#stdnt_reg_no").val());

  event.preventDefault();  // Prevent default form submission


//alert(usePath)

  if (regNo === '') {

      alert('Registration Number is required');

      return;

  }


  $.ajax({

      url: usePath + "student_info/ajax_process",

      type: 'POST',

      data: {

          'stdnt_reg_no': regNo,

          'identity': 'EMAIL'

      },

      success: function(resp) {
//alert(resp)
          if (resp.status) {

              alert("Email has been sent to the user.");

          } else {

              alert(resp.message);

          }

      },

      error: function(xhr, status, error) {

          console.error('Error:', error);

          alert('Failed to send email');

      }

  });

}





