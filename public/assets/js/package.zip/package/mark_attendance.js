$(document).ready(function(){
    flatpickr("#att_date", {
      dateFormat: "d-M-Y",
      allowInput: true,
      onOpen: function (selectedDates, dateStr, instance) {
        instance.setDate(instance.input.value, false);
      },
    });
  });

  function fill_from_subject() {
    var usePath = $.trim($("#rootXPath").val());
    var course = $.trim($("#att_subject").val());
    $("#subject-details-card").hide();
    clearStudentTable();

    if (course === "") {
        // Do nothing if no subject is selected
        return;
    }
    $.ajax({
        url: usePath + "mark_attendance/ajax_process",
        type: 'POST',
        data: {'course': course, 'requesttype': 'CODE', 'identity': 'SUBJECT'},
        async: false,
        success: function (resp) {
            if (resp.status) {
                var sdata = resp.data;
                var course = resp.course;
                var coursename = course.crse_descp; 
                
                $("#course_text").text(coursename);
                $("#semester").text(sdata.semester+" Semester");
                $("#typ").text(sdata.typ);
                $("#subject-details-card").show();
                if (sdata.typ === "Theory" || sdata.typ === "Practical") {
                  fill_group_dropdown(sdata.typ);
              }
            } else {
                // Clear values if no record found
                $("#course_text").text('');
                $("#semester").text('');
                $("#typ").text('');
                
                alert("No record(s) found.");
            }
        },
        error: function () {
            // Clear values on error
            $("#course_text").text('');
            $("#semester").text('');
            $("#typ").text('');
        },
        cache: false
    });
}

function fill_group_dropdown(subjectType) {
  var groupDropdown = $("#att_grp");
  groupDropdown.empty(); // Clear existing options
  groupDropdown.append('<option value="">Select...</option>');

  if (subjectType === "Theory") {
      var theoryGroups = ["1", "2", "3", "4"];
      $.each(theoryGroups, function (index, group) {
          groupDropdown.append(`<option value="${group}">${group}</option>`);
      });
  } else if (subjectType === "Practical") {
      var practicalGroups = ["A", "B", "C", "D"];
      $.each(practicalGroups, function (index, group) {
          groupDropdown.append(`<option value="${group}">${group}</option>`);
      });
  } else {
      groupDropdown.append('<option value="">Select...</option>');
  }
}

$(document).ready(function() {
  $("#att_grp").change(function() {
    var selectedGroup = $(this).val();
    var subjectType = $("#typ").text().trim(); // Assuming this contains 'Theory' or 'Practical'
    var usePath = $.trim($("#rootXPath").val());

    if (selectedGroup) {
      $.ajax({
        url: usePath + "mark_attendance/get_students_lists",
        type: 'POST',
        data: { 'group': selectedGroup, 'subject_type': subjectType },
        async: false,
        success: function (resp) {
          if (resp.status) {
            populateStudentTable(resp.students);
          } else {
            alert("No students found for the selected group.");
            clearStudentTable();
          }
        },
        error: function () {
          alert("Error occurred while fetching students.");
          clearStudentTable();
        },
        cache: false
      });
    } else {
      clearStudentTable();
    }
  });
});


function populateStudentTable(students) {
  var tableBody = $(".table tbody");
  tableBody.empty(); 

  $.each(students, function(index, student) {
    var isChecked = student.attendance_status === 'Y' ? 'checked' : '';
    var row = `<tr>
                  <td>${index + 1}</td>
                  <td>${student.code}</td>
                  <td>${student.name}</td>
                  <td class="text-center">
                    <input type="checkbox" name="attendance[${student.code}]" value="Y" ${isChecked} style="width: 20px;height: 25px;" />
                  </td>
               </tr>`;
    tableBody.append(row);
  });
}

function saveAttendance() {
  var usePath = $.trim($("#rootXPath").val());
  var formData = new FormData();
  var other_data = $('form#myforms').serializeArray();
  var mid = $.trim($("#markAttendanceId").val());

  $.each(other_data, function(key, input) {
    formData.append(input.name, input.value);
  });

  var att_stdnt_code = $.trim($("#att_stdnt_code").val());
  var att_attnd = $.trim($("input[name='attendance']:checked").val() || "N"); // Set to 'N' if not checked

  formData.append("identity", "ATTENDANCE");
  formData.append("markAttendanceId", mid);
  formData.append("att_stdnt_code", att_stdnt_code);
  formData.append("att_attnd", att_attnd);
  $.each(other_data, function(key, input) {
    formData.append(input.name, input.value);
  });
  $.ajax({
    url: usePath + "mark_attendance/ajax_process",
    type: 'POST',
    data: formData,
    async: false,
    contentType: false,
    processData: false,
    success: function(resp) {
      if (resp.status) {
      } else {
      }
    },
    error: function(xhr, status, error) {
    }
  });
}

function clearStudentTable() {
  var tableBody = $(".table tbody");
  tableBody.empty();
}

function fetch_subjects_by_faculty() {
  var usePath = $.trim($("#rootXPath").val());
  var facultyId = $.trim($("#att_fclty").val());

    if (facultyId === "") {
      $("#att_subject").empty().append('<option value="">Select...</option>');
      return;
  }

  $.ajax({
      url: usePath + "mark_attendance/ajax_process",
      type: 'POST',
      data: { 'faculty_id': facultyId, 'identity': 'FETCH_SUBJECTS' },
      async: false,
      success: function(resp) {
          if (resp.status) {
              var subjects = resp.data;
              var $subjectDropdown = $("#att_subject");
              $subjectDropdown.empty();
              $subjectDropdown.append('<option value="">Select...</option>');
              $.each(subjects, function(index, subject) {
                  $subjectDropdown.append('<option value="' + subject.id + '">' + subject.sub_code + '</option>');
              });
          } else {
              alert("No subjects found for the selected faculty.");
          }
      },
      error: function() {
          alert("An error occurred while fetching subjects.");
      },
      cache: false
  });
}

