
function isNumberMyKeys(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
  }

  $(document).on("click","#city_name_type_select",function(){
    $("#sidebar-menu-toggle").toggle();
  });
  function close_city_checkbox(){
    $("#sidebar-menu-toggle").hide();
  }
  $(document).ready(function() {
      // Function to handle clicking outside the menu to close it
      $(document).click(function(event) {
        var menu = $('#sidebar-menu-toggle');
        var toggleButton = $('#city_name_type_select');
    
        // Check if the click is outside the menu and the toggle button
        if (!menu.is(event.target) && menu.has(event.target).length === 0 &&
            !toggleButton.is(event.target) && toggleButton.has(event.target).length === 0) {
              close_city_checkbox();
        }
      });
  });
  function close_city_checkbox(){
    $("#sidebar-menu-toggle").hide();
  }
  
  function get_selected_item_val(){
    var selectedValues = [];
    var xvalues = [];
    var postype = []
    $("input[name='city_type_select[]']:checked").each(function(){
      postype.push($(this).attr("id"));
      xvalues.push($(this).val());
      selectedValues.push($(this).val());
    });
    if(xvalues.length > 0){
      var xvaluesJoined = xvalues.join(",");
      var postypeJoined = postype.join(",");
      $("#city_name").val(postypeJoined);
      $("#city_name_type_select").val(xvaluesJoined);
    }else{
      $("#city_name").val('');
      $("#city_name_type_select").val('');
    }
  }
  
  function filter_user_list(){
    var useroot = $("#rootXPath").val();
    $(".show_loader").removeClass("hidden");
    $(".no_loader").removeClass("hidden").addClass("hidden")
    $("#myForms").attr("action",useroot+"create_user/user_list/search");
    $("#myForms").submit();
}

function reset_user_password(reqid,userid,username){
  $("#popup_requestid").val(reqid);
  $("#popup_userid").text(userid);
  $("#popup_username").text(username);
  setTimeout(function(){ },500);
  }

     // Function to handle showing/hiding password fields based on selected option
function showHidePasswordFields(option) {
  const newPasswordField = document.getElementById('new_password');
  if (option === 'autoGenerate') {
      newPasswordField.value = generatePassword(); // Function that generates a password
      newPasswordField.type = 'password';
      newPasswordField.readOnly = true;
  } else if (option === 'createNew') {
      newPasswordField.value = '';
      newPasswordField.type = 'password';
      newPasswordField.readOnly = false;
  }
}


  // Function to generate a random password (You can use your implementation here)
function generatePassword() {
  const length = 10; // Define the length of the generated password
  const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+{}[]|:;"<>,.?/~'; // Define the characters used in the password
  let password = '';

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    password += charset[randomIndex];
  }

  return password;
}

function togglePasswordField() {
  const passwordField = document.getElementById('new_password');
  const toggleIcon = document.getElementById('togglePassword');

  if (passwordField.type === 'password') {
      passwordField.type = 'text';
      toggleIcon.classList.remove('fa-eye');
      toggleIcon.classList.add('fa-eye-slash');
  } else {
      passwordField.type = 'password';
      toggleIcon.classList.remove('fa-eye-slash');
      toggleIcon.classList.add('fa-eye');
  }
}

async function copyPasswordToClipboard() {
  const newPasswordField = document.getElementById('new_password');

  // Check if the new_password field has a value
  if (!newPasswordField.value) {
    alert('Password field is empty. Please enter a password.');
    return; // Exit the function if the password field is empty
  }

  try {
    await navigator.clipboard.writeText(newPasswordField.value);
    alert('Text copied to clipboard');
  } catch (err) {
    alert('Unable to copy text to clipboard. Error: ' + err);
  }
}

function process_reset_user_password() {
  var usePath = $.trim($("#rootXPath").val());
  var new_pass = $.trim($("#new_password").val());
  var requestid = $.trim($("#popup_requestid").val());

  if (new_pass === '') {
    alert("New Password is required");
    $("#new_password").focus();
    return false;
  } else if (requestid === '') {
    alert("User ID is required.");
    return false;
  }
  $(".unprocess_loader").removeClass("hidden");
  $(".process_loader").addClass("hidden");

 
    $.ajax({
      url: usePath + "create_user/ajax_process",
      type: 'POST',
      data: { 'reqid': requestid, 'new_pass': new_pass,'identity': 'RESET' },
      async: false,
      success: function (resp) {
        $(".unprocess_loader").addClass("hidden");
        $(".process_loader").removeClass("hidden");

        if (resp.status) {
          alert("Password reset successful.");
          //window.location = window.location.href;
        } else {
          alert("Unable to process");
        }
       
      },
      error: function () {
        $(".unprocess_loader").addClass("hidden");
        $(".process_loader").removeClass("hidden");
      },
      cache: false
    });
 
}

function show_create_check_user_listmodule(){  
  $("#myDIV").toggleClass("hidden")
  var classname = $("#process_side_updown").attr("class");
  if( classname == 'fa fa-plus text-success'){
      $("#process_side_updown").removeClass("fa fa-plus text-success").addClass("fa fa-minus text-danger");
  }else if( classname == 'fa fa-minus text-danger'){
      $("#process_side_updown").removeClass("fa fa-minus text-danger").addClass("fa fa-plus text-success");
  }
  
}