$(document).on("keypress","#user_search",function(e){
    var keycode = (e.keyCode ? e.keyCode : e.which );
      if( keycode == '13' ){
        filter_user_log();
      }
  
  });
function filter_user_log(){
    var useroot = $("#rootXPath").val();
    //alert(useroot)

    $("form#myforms").attr("action",useroot+"log_audit/search");
    $("form#myforms").submit();
}
function alertChecked(url){
    if( confirm("Are you sure want to delete ?")){
        window.location = url
    }
}