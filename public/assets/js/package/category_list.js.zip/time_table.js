function save_time_table() {
    var usePath              = $.trim( $("#rootXPath").val() );
    var formData             = new FormData();
    var other_data           = $('form#myforms').serializeArray();
    var mid                  = $.trim( $("#timetableid").val() );
    var year                 = $.trim( $("#tt_year").val() );	
    var subject              = $.trim( $("#tt_subject").val() );
    var day                  = $.trim( $("#tt_day").val() );	
    var period              = $.trim( $("#tt_period").val() );
    var faculty             = $.trim( $("#tt_faculty").val() );	
    if (year == '') {
      showToast('warning', 'Year is required.');
      $("#tt_year").focus();
      return false;
  } else if (subject == '') {
      showToast('warning', 'Subject is required.');
      $("#tt_subject").focus();
      return false;
  }else if (day == '') {
    showToast('warning', 'Day is required.');
    $("#tt_day").focus();
    return false;
  }else if (period == '') {
    showToast('warning', 'Period is required.');
    $("#tt_period").focus();
    return false;
  }else if (faculty == '') {
    showToast('warning', 'Faculty is required.');
    $("#tt_faculty").focus();
    return false;
  }
    $.each(other_data,function(key,input){
      formData.append(input.name,input.value);
  });

    var tt_year              = $.trim( $("#tt_year").val() );

    formData.append("identity", "TIMETABLE");
  
    formData.append("timetableid", mid);
    formData.append("tt_year", tt_year);
    $.each(other_data,function(key,input){
        formData.append(input.name,input.value);
    });
    
     $(".process_qualif_save").hide();
      $.ajax({
             url: usePath+"time_table/ajax_process",
             type: 'POST',
             data: formData,
             async: false,
             contentType: false,
             processData: false,
             success: function (resp) {
                  var vhtml = '';
                 var typex = "'QLF'";
                if( resp.status ){
                      
                       
                         showToast("Success", resp.message);
                         $("#process_time_table").html(resp.data);
                         setTimeout(function(){ reset_qualification_afteradd();
                            
                         },500);
                }else{
                    $(".process_qualif_save").show();
                    showToast("Success", resp.message);
                  
                }
             },
             error: function () {
                 $(".process_qualif_save").show();
             },
             cache: false
     });
  }

  function reset_qualification_afteradd(){
    $("#timetableid").val('');
    $("#tt_year").val('')
    $("#tt_day").val('');
    $("#tt_period").val('') ;
    $("#tt_faculty").val('');
    $("#tt_subject").val('');
  }

  // Toastr Custom Function
  function showToast(type, message, heading = '', position = 'top-center', hideAfter = 3000) {
    $.toast({
        heading: heading, // Optional title for the toast
        text: message,    // Main message text
        showHideTransition: 'fade', // Transition effect ('plain', 'fade', or 'slide')
        icon: type,       // Type: 'info', 'success', 'warning', or 'error'
        position: position, // Position: 'top-right', 'top-left', 'bottom-right', 'bottom-left'
        hideAfter: hideAfter, // Duration before auto-hiding the toast (in milliseconds)
        stack: false,     // Allow only one toast at a time
        loader: true,     // Enable the progress bar
        loaderBg: '#9EC600' // Progress bar color
    });
}

$(document).on("keypress","#tt_subject",function(e){
  var keycode = (e.keyCode ? e.keyCode : e.which );
    if( keycode == '13' ){
      filter_time_table();
    }

});
function filter_time_table(){
    var useroot = $("#rootXPath").val();
    $(".show_loader").removeClass("hidden");
    $(".no_loader").removeClass("hidden").addClass("hidden")
    $("form#myforms").attr("action",useroot+"time_table/search");
    $("form#myForms").submit(); 

}

function get_time_table_sheet_list(){
    var usePath              = $.trim( $("#rootXPath").val() );
    var formData             = new FormData();
    //var other_data           = $('form#myforms').serializeArray();     
    var subject              = $.trim( $("#tt_subject").val() );   
    var tt_year              = $.trim( $("#tt_year").val() );
    formData.append("identity", "VWTIMETABLE");
    formData.append("tt_year", tt_year);
    formData.append("tt_subject", subject);
     
      $.ajax({
             url: usePath+"time_table/ajax_process",
             type: 'POST',
             data: formData,
             async: false,
             contentType: false,
             processData: false,
             success: function (resp) { 
                var ntml = '<tr><td colspan="4">No record(s) found.</td></tr>'          
                if( resp.status ){
                   $("#process_time_table").html(resp.data);                        
                }else{
                  $("#process_time_table").html(ntml); 
                }
             },
             error: function () {
                 
             },
             cache: false
     });
}

function view_faculty_time_table(){
  var usePath              = $.trim( $("#rootXPath").val() );
  var formData             = new FormData();
  //var other_data         = $('form#myforms').serializeArray();     
  var tt_faculty           = $.trim( $("#tt_faculty").val() );   
  var tt_year              = $.trim( $("#tt_year").val() );
  formData.append("identity", "FACULTYIMETABLE");
  formData.append("tt_year", tt_year);
  formData.append("tt_faculty", tt_faculty);
   
    $.ajax({
           url: usePath+"time_table/ajax_process",
           type: 'POST',
           data: formData,
           async: false,
           contentType: false,
           processData: false,
           success: function (resp) { 
              var ntml = '<tr><td colspan="4">No record(s) found.</td></tr>'          
              if( resp.status ){
                 $("#process_time_table").html(resp.data);                        
              }else{
                $("#process_time_table").html(ntml); 
              }
           },
           error: function () {
               
           },
           cache: false
   });
}